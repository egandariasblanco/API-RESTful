import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='endgand',
    application_name='todo-list-serverless',
    app_uid='VKZqw5c0vZT3PBQJFQ',
    org_uid='0b2f6e0a-d4d1-4dd1-a492-c9ee9f4770bc',
    deployment_uid='ae62465d-de6d-4ba3-9eeb-82bd3e013571',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
